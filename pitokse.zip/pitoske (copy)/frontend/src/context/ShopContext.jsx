import { createContext, useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

export const ShopContext = createContext();

const ShopContextProvider = (props) => {
  const currency = "₹";
  const delivery_fee = 100;
  const backendurl = import.meta.env.VITE_BACKEND_URL;

  const [search, setSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [token, setToken] = useState("");

  const [cartItems, setCartItems] = useState(() => {
    const stored = localStorage.getItem("cartItems");
    return stored ? JSON.parse(stored) : {};
  });

  const [products, setProducts] = useState([]);
  const navigate = useNavigate();

  // Save cart locally too
  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  // ----------------------------------------------
  // LOAD PRODUCTS
  // ----------------------------------------------
  const getProductsData = async () => {
    try {
      const response = await axios.get(backendurl + "/api/product/list");

      if (response.data.success) {
        setProducts(response.data.products);
      } else {
        toast.error(response.data.message);
      }
    } catch (err) {
      toast.error(err.message);
    }
  };

  useEffect(() => {
    getProductsData();
  }, []);

  // ----------------------------------------------
  // LOAD CART FROM BACKEND
  // ----------------------------------------------
  const loadCartData = async (token) => {
    try {
      const res = await axios.post(
        backendurl + "/api/cart/get",
        {},
        { headers: { token } }
      );

      if (res.data.success) {
        setCartItems(res.data.cartData);
      }
    } catch (error) {
      console.log(error);
    }
  };

  // Restore token on refresh
  useEffect(() => {
    const saved = localStorage.getItem("token");
    if (saved) setToken(saved);
  }, []);

  // When token loads => load cart from backend
  useEffect(() => {
    if (token) loadCartData(token);
  }, [token]);

  // ----------------------------------------------
  // ADD TO CART
  // ----------------------------------------------
  const addToCart = async (itemId, size) => {
    if (!size || size.trim() === "") {
      toast.error("Please select a size");
      return;
    }

    // Update local cart instantly
    setCartItems((prev) => {
      const newCart = { ...prev };
      if (!newCart[itemId]) newCart[itemId] = {};
      newCart[itemId][size] = (newCart[itemId][size] || 0) + 1;
      return newCart;
    });

    // Update backend
    if (token) {
      try {
        await axios.post(
          backendurl + "/api/cart/add",
          { itemId, size },
          { headers: { token } }
        );
      } catch (error) {
        console.log(error);
      }
    }

    toast.success("Added to cart!");
  };

  // ----------------------------------------------
  // REMOVE FROM CART
  // ----------------------------------------------
  const removeFromCart = async (itemId, size) => {
    let newQty =
      (cartItems[itemId]?.[size] ? cartItems[itemId][size] : 1) - 1;

    setCartItems((prev) => {
      const newCart = { ...prev };

      if (newCart[itemId] && newCart[itemId][size] > 0) {
        newCart[itemId][size]--;

        if (newCart[itemId][size] === 0) {
          delete newCart[itemId][size];
          if (Object.keys(newCart[itemId]).length === 0) delete newCart[itemId];
        }
      }

      return newCart;
    });

    if (token) {
      try {
        await axios.post(
          backendurl + "/api/cart/update",
          { itemId, size, quantity: newQty },
          { headers: { token } }
        );
      } catch (error) {
        console.log(error);
      }
    }
  };

  // ----------------------------------------------
  // UPDATE QUANTITY
  // ----------------------------------------------
  const updateQuantity = async (itemId, size, quantity) => {
    setCartItems((prev) => {
      const newCart = { ...prev };

      if (quantity <= 0) {
        delete newCart[itemId][size];
        if (Object.keys(newCart[itemId]).length === 0) {
          delete newCart[itemId];
        }
      } else {
        if (!newCart[itemId]) newCart[itemId] = {};
        newCart[itemId][size] = quantity;
      }

      return newCart;
    });

    if (token) {
      try {
        await axios.post(
          backendurl + "/api/cart/update",
          { itemId, size, quantity },
          { headers: { token } }
        );
      } catch (err) {
        console.log(err);
      }
    }
  };

  // ----------------------------------------------
  // TOTAL AMOUNT
  // ----------------------------------------------
  const getTotalCartAmount = () => {
    let total = 0;

    for (const id in cartItems) {
      for (const size in cartItems[id]) {
        const qty = cartItems[id][size];
        const info = products.find((p) => p._id === id);

        if (info) total += info.price * qty;
      }
    }

    return total;
  };

  // ----------------------------------------------
  // CART COUNT
  // ----------------------------------------------
  const getCartCount = () => {
    let total = 0;

    for (const id in cartItems)
      for (const size in cartItems[id])
        total += cartItems[id][size];

    return total;
  };

  // ----------------------------------------------
  // CONTEXT EXPORT
  // ----------------------------------------------
  const value = {
    products,
    currency,
    delivery_fee,

    search,
    setSearch,
    showSearch,
    setShowSearch,

    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,

    getTotalCartAmount,
    getCartCount,

    navigate,
    backendurl,
    token,
    setToken,
    setCartItems
  };

  return (
    <ShopContext.Provider value={value}>
      {props.children}
    </ShopContext.Provider>
  );
};

export default ShopContextProvider;
