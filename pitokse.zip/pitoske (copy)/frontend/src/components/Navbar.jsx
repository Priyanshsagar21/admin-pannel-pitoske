import React, { useState, useContext } from "react";
import { assets } from "../assets/assets";
import { NavLink, Link } from "react-router-dom";
import { ShopContext } from "../context/ShopContext";

const Navbar = () => {
  const [visible, setVisible] = useState(false);

  const {
    setShowSearch,
    getCartCount,
    navigate,
    token,
    setToken,
    setCartItems,
    loadingToken,
  } = useContext(ShopContext);

  // ⚡ Wait for token to load
  if (loadingToken) return null;

  const Logout = () => {
    localStorage.removeItem("token");
    setToken("");
    setCartItems({});
    navigate("/login");
  };

  return (
    <>
      {/* NAVBAR */}
      <div className="fixed top-0 left-0 w-full z-50 backdrop-blur-md bg-white/70 shadow-md border-b border-white/30 flex items-center justify-between py-4 px-4 sm:px-[5vw] md:px-[7vw] lg:px-[9vw]">
        
        <Link to="/">
          <img src={assets.logo} className="w-36" alt="logo" />
        </Link>

        <ul className="hidden sm:flex gap-5 text-sm text-gray-700">
          <NavLink to="/">HOME</NavLink>
          <NavLink to="/collection">COLLECTION</NavLink>
          <NavLink to="/about">ABOUT</NavLink>
          <NavLink to="/contact">CONTACT</NavLink>
        </ul>

        <div className="flex items-center gap-6">
          <img
            src={assets.search_icon}
            className="w-5 cursor-pointer"
            onClick={() => setShowSearch(true)}
          />

          {/* Profile */}
          <div className="group relative">
            {token ? (
              <img
                src={assets.profile_icon}
                className="w-5 cursor-pointer"
                alt="profile"
              />
            ) : (
              <Link to="/login">
                <img src={assets.profile_icon} className="w-5 cursor-pointer" />
              </Link>
            )}

            {token && (
              <div className="group-hover:block hidden absolute right-0 pt-4">
                <div className="flex flex-col gap-2 w-36 py-3 bg-slate-100/90 text-gray-500 rounded-lg">
                  <p className="hover:text-black cursor-pointer">My Profile</p>
                  <p onClick={()=>navigate('/orders')} className="hover:text-black cursor-pointer">Orders</p>
                  <p className="hover:text-black cursor-pointer" onClick={Logout}>
                    Logout
                  </p>
                </div>
              </div>
            )}
          </div>

          <Link to="/cart" className="relative">
            <img src={assets.cart_icon} className="w-5" />
            <p className="absolute right-[-5px] bottom-[-5px] w-4 text-center leading-4 bg-black text-white rounded-full text-[8px]">
              {getCartCount()}
            </p>
          </Link>

          <img
            onClick={() => setVisible(true)}
            src={assets.menu_icon}
            className="w-5 sm:hidden"
          />
        </div>
      </div>

      {/* Mobile Sidebar */}
      <div
        className={`fixed top-0 right-0 h-full z-[60] backdrop-blur-xl bg-white/80 shadow-xl transition-all duration-500 ${
          visible ? "translate-x-0 w-3/4" : "translate-x-full w-0"
        } sm:hidden`}
      >
        <div className="flex flex-col">
          <div
            onClick={() => setVisible(false)}
            className="flex items-center gap-4 p-4 border-b border-gray-200"
          >
            <img className="h-4 rotate-180" src={assets.dropdown_icon} />
            <p>Back</p>
          </div>

          <NavLink to="/" className="py-3 pl-6 border-b">HOME</NavLink>
          <NavLink to="/collection" className="py-3 pl-6 border-b">COLLECTION</NavLink>
          <NavLink to="/about" className="py-3 pl-6 border-b">ABOUT</NavLink>
          <NavLink to="/contact" className="py-3 pl-6 border-b">CONTACT</NavLink>
        </div>
      </div>
    </>
  );
};

export default Navbar;
