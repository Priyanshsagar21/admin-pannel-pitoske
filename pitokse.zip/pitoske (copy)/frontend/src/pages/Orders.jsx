import React, { useContext, useEffect, useState } from "react";
import { ShopContext } from "../context/ShopContext";
import Title from "../components/Title";
import axios from "axios";

const Orders = () => {
  const { backendurl, token, currency } = useContext(ShopContext);
  const [orderData, setOrderData] = useState([]);

  const loadOrderData = async () => {
    try {
      if (!token) return;

      const response = await axios.post(
        backendurl + "/api/order/userorder",
        {},
        { headers: { token } }
      );

      if(response.data.success){
        let allOrderItems = []
        response.data.orders.map((order)=>{
          order.items.map((item)=>{
            item['status'] = order.status,
            item['payment'] = order.payment,
            item['paymentMethod'] = order.paymentMethod,
            item['date'] = order.date,
            allOrderItems.push(item)

          })
        })
        setOrderData(allOrderItems)
      }
      if (response.data.success) {
        setOrderData(response.data.orders);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    loadOrderData();
  }, [token]);

  return (
    <div className="border-t pt-16 px-4 sm:px-[5%]">
      <div className="text-2xl mb-8">
        <Title text1={"MY"} text2={"ORDERS"} />
      </div>

      <div>
        {orderData.map((item, index) => (
          <div
            key={index}
            className="py-4 border-t border-b text-gray-700 flex flex-col md:flex-row md:items-center md:justify-between gap-4"
          >
            <div className="flex items-start gap-6 text-sm w-full md:w-3/4">
              <img
                className="w-16 sm:w-20 rounded-md object-cover"
                src={item.items[0].image[0]}
              />

              <div>
                <p className="sm:text-base font-medium">
                  {item.items[0].name}
                </p>

                <div className="flex items-center gap-3 mt-2 text-base">
                  <p className="text-lg font-semibold">
                    {currency}
                    {item.items[0].price}
                  </p>

                  <p>Quantity: {item.items[0].quantity}</p>
                  <p>Size: {item.items[0].size}</p>
                </div>

                <p className="mt-1 text-sm text-gray-500">
                  Date: {new Date(item.date).toLocaleDateString()}
                </p>
              </div>
            </div>

            <div className="text-sm md:text-base md:w-1/4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              {item.status}
            </div>

            <button className="border px-4 py-2 text-sm font-medium rounded-sm">
              TRACK ORDER
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Orders;
