import jwt from 'jsonwebtoken';



const authAdmin = async(req,resp,next) =>{
    try {
        const {token} = req.headers 

        if (! token) {

            return resp.json({success:false,message: "Not authorized Login again"})
            
        }
        
        const token_decode =  jwt.verify(token,process.env.JWT_SECRET)

        if(token_decode !== process.env.ADMIN_EMAIL + process.env.ADMIN_PASSWORD){
            return resp.json({success:false,message: "Not authorized Login again"})

        }
        next()
    } catch (error) {
        console.log(error)
        resp.json({success:false,message:error.message})
        
    }
}


export default authAdmin;