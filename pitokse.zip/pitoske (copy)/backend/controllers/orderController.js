  import orderModel from "../models/orderModel.js";
  import userModel from "../models/userModel.js";
  
  /// cod method
  const  placeOrder =  async (req,resp) =>{

    try {
      const {userId , items , amount , address} = req.body; 

      const orderData = {
        userId,
        items,
        amount,
        paymentMethod : "cod",
        payment : false,
        date :Date.now(),
        address
      }

      const newOrder = new orderModel(orderData)
      await newOrder.save()


      await userModel.findByIdAndUpdate(userId,{cartData:{}})


      resp.json({success:true , message:"Order Has Been Placed"})
 

      
    } catch (error) {
      console.log(error);
      resp.json({success:false, message:error.message})
      
    }

  }



   /// stripe  method
  const  placeOrderStripe =  async (req,resp) =>{
    
  }



   /// razorpay method
  const  placeOrderRazorpay =  async (req,resp) =>{
    
  }



  /// all orders data for admin pannel

  const allOrders = async(req,resp) =>{

  }



  /// userOrder details

  const  userOrder = async(req,resp) =>{
    try {
      const {userId} = req.body;
      const orders = await orderModel.find({userId})

      resp.json({success:true , orders})
      console.log("ORDER ITEMS:", response.data.orders[0].items);


      
    } catch (error) {
      
      console.log(error);
      resp.json({success:false, message:error.message})
    }

  }



  ///upate order status

  const  updateStatus  = async(req,resp) =>{

  }


  export {placeOrder,placeOrderStripe,placeOrderRazorpay,userOrder,updateStatus,allOrders}