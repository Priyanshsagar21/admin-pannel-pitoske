import validator from "validator";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import userModel from "../models/userModel.js";

const createToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET);
};

import { json } from "express";

// route for user login
const loginUser = async (req, resp) => {
  try {
    const { email, password } = req.body;
    const user = await userModel.findOne({ email });

    if (!user) {
      return resp.json({
        success: false,
        message: "user does not exists please register",
      });
    }
    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch) {
      const token = createToken(user._id);
      resp.json({ success: true, token });
    } else {
      resp.json({ success: false, message: "incorrect password" });
    }
  } catch (error) {
    console.log(error);
    resp.json({ success: true, message: error.message });
  }
};

// route for user register
const registerUser = async (req, resp) => {
  try {
    const { name, email, password } = req.body;

    const exists = await userModel.findOne({ email });
    if (exists) {
      return resp.json({ success: false, message: "user allready exists" });
    }
    //   email validation and strong password checked
    if (!validator.isEmail(email)) {
      return resp.json({ success: false, message: "Please enter valid email" });
    }
    if (password.length < 8) {
      return resp.json({
        success: false,
        message: "Please enter password more than 8 charter & also strong",
      });
    }

    // hasing user password
    const salt = await bcrypt.genSalt(10);
    const hashedpassword = await bcrypt.hash(password, salt);

    const newUser = new userModel({
      name,
      email,
      password: hashedpassword,
    });

    const user = newUser.save();

    const token = createToken(user._id);

    resp.json({ success: true, token });
  } catch (error) {
    console.log(error);
    resp.json({ success: true, message: error.message });
  }
};

// route for Admin login
const adminLogin = async (req, resp) => {

  try {
    const {email,password} = req.body
    if(email ===process.env.ADMIN_EMAIL && password ===process.env.ADMIN_PASSWORD){
      const token = jwt.sign(email+password,process.env.JWT_SECRET)
      resp.json({success:true,token})
    }else{
      resp.json({success:false,message:"invalid candidte"})
    }
  } catch (error) {
    
  resp.json({success:false,message:error.message})
  
  }
};

// export functions
export { loginUser, registerUser, adminLogin };
