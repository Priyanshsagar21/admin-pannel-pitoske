import { json } from "express";
import {v2 as cloudinary} from 'cloudinary';
import productModel from "../models/productModel.js";


// function for add products
const addProduct = async (req, resp) => {
  try {
    const { name, description, price, category, subCategory, sizes, bestseller } = req.body;

    const image1 = req.files.image1?.[0];
    const image2 = req.files.image2?.[0];
    const image3 = req.files.image3?.[0];
    const image4 = req.files.image4?.[0];

    const images = [image1, image2, image3, image4].filter(Boolean);

    const imagesUrl = await Promise.all(
      images.map(async (item) => {
        const result = await cloudinary.uploader.upload(item.path, { resource_type: "image" });
        return result.secure_url;
      })
    );

    const productData = {
      name,
      description,
      price: Number(price),
      category,
      subCategory,
      sizes: JSON.parse(sizes),    
      bestSeller: bestseller === "true",
      image: imagesUrl,            
      date: Date.now()
    };

    console.log(productData);

    const product = new productModel(productData);
    await product.save();

    resp.json({ success: true, message: "Product Added" });

  } catch (error) {
    resp.json({ success: false, message: error.message });
  }
};




// function for list products
const listProducts = async (req, resp) => {

  try {
    const products = await productModel.find({})
    resp.json({success:true,products})
    
  } catch (error) {
    console.log(error);
    resp.json({success:false,message:error.message})
    
  }
};


// function for removeing  products
const removeProducts = async (req, resp) => {
try {
  
      await productModel.findByIdAndDelete(req.body.id)
    resp.json({success:true,message:"Product Removed "})
} catch (error) {

    console.log(error);
    resp.json({success:false,message:error.message})
  
}

};


// function for single product info
const singleProduct = async (req,resp) => {
  try {

    const {productId} = req.body;
    const product = await productModel.findById(productId)
  
    resp.json({success:true,product})
} catch (error) {


    console.log(error);
    resp.json({success:false,message:error.message})
  
}
};

export { addProduct, listProducts, removeProducts, singleProduct };