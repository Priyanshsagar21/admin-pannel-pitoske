import userModel from "../models/userModel.js";

// ---------------------------
// ADD TO CART
// ---------------------------
export const addToCart = async (req, resp) => {
  try {
    const { userId, itemId, size } = req.body;

    const userData = await userModel.findById(userId);
    let cartData = userData.cartData;

    if (!cartData[itemId]) {
      cartData[itemId] = {};
    }

    if (cartData[itemId][size]) {
      cartData[itemId][size] += 1;
    } else {
      cartData[itemId][size] = 1;
    }

    await userModel.findByIdAndUpdate(userId, { cartData });

    resp.json({ success: true, message: "Added to Cart" });


  } catch (error) {
    console.log(error);
    resp.json({ success: false, message: error.message });
  }
};

// ---------------------------
// UPDATE CART
// ---------------------------
export const updateCart = async (req, resp) => {
  try {
    const { userId, itemId, size, quantity } = req.body;

    const userData = await userModel.findById(userId);
    let cartData = userData.cartData;

    if (quantity <= 0) {
      delete cartData[itemId][size];

      if (Object.keys(cartData[itemId]).length === 0) {
        delete cartData[itemId];
      }

    } else {
      if (!cartData[itemId]) cartData[itemId] = {};
      cartData[itemId][size] = quantity;  // ✅ FIXED
    }

    await userModel.findByIdAndUpdate(userId, { cartData });

    resp.json({ success: true, message: "Cart Updated" });

  } catch (error) {
    console.log(error);
    resp.json({ success: false, message: error.message });
  }
};

// ---------------------------
// GET USER CART
// ---------------------------
export const getUserCart = async (req, resp) => {
  try {
    const { userId } = req.body;

    const userData = await userModel.findById(userId);
    let cartData = userData.cartData;

    resp.json({ success: true, cartData });

  } catch (error) {
    console.log(error);
    resp.json({ success: false, message: error.message });
  }
};


export default { addToCart, updateCart, getUserCart };
