import express from "express";
import { addProduct,removeProducts,listProducts,singleProduct } from "../controllers/productController.js";
import upload from "../middleware/multer.js";
import authAdmin from "../middleware/adminAuth.js";

const productsRouter = express.Router();


productsRouter.post("/add",authAdmin,upload.fields([{name:'image1',maxCount:1},{name:'image2',maxCount:1},{name:'image3',maxCount:1},{name:'image4',maxCount:1}]),addProduct);
productsRouter.post("/remove",authAdmin ,removeProducts);
productsRouter.get("/list",listProducts);
productsRouter.post("/single",singleProduct);



export default productsRouter;
  

